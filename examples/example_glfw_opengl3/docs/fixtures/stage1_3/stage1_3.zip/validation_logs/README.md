# Validation Logs

Drop QuestDB and Postgres validation outputs here after running exports or ingesting staged data. Suggested filenames:
- `btc25_1_questdb.txt`
- `btc25_run1_postgres.txt`

Each file should contain the raw query plus the result set to simplify auditing on the backend/frontend hosts.
